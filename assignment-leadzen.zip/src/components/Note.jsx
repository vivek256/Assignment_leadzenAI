import React from "react";

function Note(props) {
  function handleClick() {
    props.onDelete(props.id);
  }

  return (
    <div className="note">
      <h1>{props.title}</h1>
      <p>{props.content}</p>
      <input type="checkbox" defaultChecked={false} style={{ padding: "20px" }} />
      <button onClick={handleClick}>DELETE</button>
    </div>
  );
}

export default Note;
